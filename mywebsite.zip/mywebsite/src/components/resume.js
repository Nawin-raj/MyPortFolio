import React, { Component } from 'react';
import { Grid, Cell } from 'react-mdl';
import Education from './education';
import Experience from './experience';
import Skills from './skills';
import logo from './nawin-min.jpg';
import Projects from './Projects';


class Resume extends Component {
  render() {
    return (
      <div>
        <Grid>
          <Cell col={4}>
            <div style={{ textAlign: 'center' }}>
              <img
                src={logo}
                alt="avatar"
                style={{ height: '200px', borderRadius: '20px' }}
              />
            </div>
            <h2 style={{ paddingTop: '0em' }}>Naveen Kumar</h2>
            <h4 style={{ color: 'grey' }}>Programmer</h4>
            <hr style={{ borderTop: '3px solid #833fb2', width: '50%' }} />
            <p>To become a successful professional in the flied of Information Technology
               and to work in an innovative and competitive organization hich help 
               me to explore myself and ultimately benefit the organization by using best of it.
            </p>
            <hr style={{ borderTop: '3px solid #833fb2', width: '50%' }} />
            <h5>Address</h5>
            <p>Hyderabad, Telangana Dist</p>
            <h5>Phone</h5>
            <p>7036188576</p>
            <h5>Email</h5>
            <p>naveenkumarsahukari@gmail.com</p>
          </Cell>
          <Cell className="resume-right-col" col={8}>
            <h3>Education</h3>


            <Education />



            <hr style={{ borderTop: '3px solid #e22557' }} />

            <h3>Experience</h3>

            <Experience
              startYear={"July 2019-Present"}
              jobName={"Softare Developer"}
              jobDescription="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
            />


            <hr style={{ borderTop: '3px solid #e22947' }} />
            <h3>Skills</h3>
            <Skills></Skills>
            <hr style={{ borderTop: '3px solid #e22947' }} />
            <Projects></Projects>




          </Cell>
        </Grid>
      </div>
    )
  }
}

export default Resume;