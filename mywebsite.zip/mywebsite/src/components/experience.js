import React, { Component } from 'react';

class Experience extends Component {
  render() {
    return (
      <div>
        <div>
          <span id="makeLeft"> <b>Company:</b> COGNIZANT</span>
          <span id="makeRight"> July-2019 - Present</span>
        </div>
        <p></p>
        <p><b>Role:</b> Softare developer</p>
        <p><b>Project details:</b></p>
        <p>Zelle is a online banking application,  by using that we can do all bank related operations. </p>
      </div>
    )
  }
}

export default Experience;