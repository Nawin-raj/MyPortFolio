import React, { Component } from 'react';


class Skills extends Component {
  render() {
    return (
      <div>
        <table>
          <tr>
            <th>Languages:</th>
            <th>Java, JavaScript</th>
          </tr>
          <tr>
            <th>Web technologies:</th>
            <th>HTML, CSS, JQuery, Servelts&JSp</th>
          </tr>
          <tr>
            <th>Database:</th>
            <th>MySQL</th>
          </tr>
          <tr>
            <th>Frameworks:</th>
            <th>React, Spring core & MVC</th>
          </tr>






        </table>
      </div>
    )
  }
}

export default Skills;