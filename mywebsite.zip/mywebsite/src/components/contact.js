import React, { Component } from 'react';
import { Grid, Cell } from 'react-mdl';
import logo from './nawin-min.jpg';


class Contact extends Component {
    render() {
        return (
            <div style={{backgroundColor:'#FFE4B5'}} className="contact-body">
                <Grid  style={{backgroundColor:'#FFE4B5'}}className="contact-grid">
                    <Cell col={6}>
                        <h2>Naveen Kumar</h2>
                        <img
                            src={logo}
                            alt="avatar"
                            style={{ height: '200px', borderRadius: '10px' }}
                        />
                        <p style={{ width: '75%', margin: 'auto', paddingTop: '1em' }}>
                            HELLO EVERYBODY, I AM
                            </p>
                            <p> NAVEEN KUMAR </p>
                            <p>JUNIOR JAVA DEVELOPER</p>
                                

                    </Cell>
                    <Cell col={6}>
                        <h2>Contact Me</h2>
                        <div className="contact-list">
                            <h5>Phone: 703688576</h5>
                            <h5>Gmail: Naveenkumarsahukari@gmail.com</h5>



                        </div>
                    </Cell>
                </Grid>
            </div>
        )
    }
}

export default Contact;