import React, { Component } from 'react';


class Projects extends Component {
    render() {
        return (
            <div>
                <h3>Projects</h3>

               <b> <li>Movie rating application using Spring Boot Microservies</li></b>
                <p></p>
                <b><li>Simple Todo application using Spring MVC and react</li></b>
            </div>
        )
    }
}

export default Projects;