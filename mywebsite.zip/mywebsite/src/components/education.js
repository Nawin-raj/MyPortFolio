import React, { Component } from 'react';
import { Grid, Cell } from 'react-mdl';

class Education extends Component {
    render() {
        return (
            <div>
                <table>
                    <tr>
                        <th>Qualification</th>
                        <th>INSTITUTE</th>
                        <th>Passout Year</th>
                        <th>Percentage</th>

                    </tr>
                    <tr>
                        <td>B.Tech</td>
                        <td>AITAM</td>
                        <td>2019</td>
                        <td>70</td>
                      
                    </tr>
                    <tr>
                        <td>Diploma</td>
                        <td>AITAM</td>
                        <td>2016</td>
                        <td>76</td>
                    </tr>

                </table>
            </div>
        )
    }
}

export default Education;